from odoo import http
from odoo.http import request


class TrademarkApplicant2(http.Controller):

    @http.route("/trademark/application", type="http", website=True, auth='public')
    def trademark_details(self, **kw):
        data = {}
        return http.request.render("trial.trademark_form", data)

    @http.route("/trademark/application/success", type="http", website=True, auth='public')
    def submit_data(self, **kw):

        trademark_data = kw
        print("=========================={}".format(trademark_data))

        request.env['trial.application'].sudo().create(trademark_data)
        return http.request.render('trial.confirm')
