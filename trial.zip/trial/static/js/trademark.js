$(document).ready(function () {
  // Custom method to validate username
  $.validator.addMethod(
    "usernameRegex",
    function (value, element) {
      return this.optional(element) || /^[a-zA-Z0-9]*$/i.test(value);
    },
    "Username must contain only letters, numbers"
  );
  $('input[name^="fileupload"]').each(function () {
    $(this).rules("add", {
      required: true,
      accept: "image/jpeg, image/pjpeg",
    });
  });

  $(".next").click(function () {
    //GETTING ALL USER INPUT VALUES
    var registrationPartField = document.getElementById("registrationPart")
      .value;
    var registrationServicesClassField = document.getElementById(
      "registrationServicesClass"
    ).value;
    var agencyTypeField = document.getElementById("agencyType").value;
    var trademarkStatusField = document.getElementById("trademarkStatus").value;
    var uploadFileField = document.getElementById("uploadFile").value;
    var additionalInfoField = document.getElementById("additionalInfo").value;
    var companyNameField = document.getElementById("companyName").value;
    var addressField = document.getElementById("address").value;
    var emailField = document.getElementById("email").value;
    var telephoneField = document.getElementById("telephone").value;

    //GEG ALL USER INPUT VALUES
    document.getElementById(
      "registrationPartData"
    ).innerHTML = registrationPartField;
    document.getElementById(
      "registrationServicesClassData"
    ).innerHTML = registrationServicesClassField;
    document.getElementById("agencyTypeData").innerHTML = agencyTypeField;
    document.getElementById(
      "trademarkStatusData"
    ).innerHTML = trademarkStatusField;
    document.getElementById("uploadFileData").innerHTML = uploadFileField;
    document.getElementById(
      "additionalInfoData"
    ).innerHTML = additionalInfoField;
    document.getElementById("companyNameData").innerHTML = companyNameField;
    document.getElementById("addressData").innerHTML = addressField;
    document.getElementById("emailData").innerHTML = emailField;
    document.getElementById("telephoneData").innerHTML = telephoneField;

    var form = $("#trademark_form");
    form.validate({
      errorElement: "span",
      errorClass: "help-block",
      highlight: function (element, errorClass, validClass) {
        $(element).closest(".form-group").addClass("has-error");
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).closest(".form-group").removeClass("has-error");
      },
      rules: {
        registrationPart: {
          required: true,
        },
        registrationServicesClass: {
          required: true,
        },

        agencyType: {
          required: true,
        },
        trademarkStatus: {
          required: true,
        },
        uploadFile: {
          required: true,
        },
        additionalInfo: {
          required: true,
        },
        companyName: {
          required: true,
        },
        address: {
          required: true,
        },
        email: {
          email: true,
          required: true,
        },
        telephone: {
          required: true,
        },
      },
      messages: {
        registrationPart: {
          required: "Permit type is required",
        },
        registrationServicesClass: {
          required: "Registration service class is required",
        },
        agencyType: {
          required: "This field is required",
        },
        trademarkStatus: {
          required: "trademark status is required",
        },
        uploadFile: {
          required: "file is required",
        },
        additionalInfo: {
          required: "This field is required",
        },
        companyName: {
          required:
            "Here insert legibly the full name, description and nationality of the individual\
            firm or body corporate making the application.The names of all partners in a firm must be given in full\
                                               If the applicant is a body corporate, the kind and country of incorporation should be stated.",
        },
        address: {
          required: "Address is required",
        },
        email: {
          required: "Email is required",
        },
        telephone: {
          required: "Please enter your phone Number",
        },
      },
    });
    if (form.valid() === true) {
      if ($("#trademark1_information").is(":visible")) {
        current_fs = $("#trademark1_information");
        next_fs = $("#trademark2_information");
      } else if ($("#trademark2_information").is(":visible")) {
        current_fs = $("#trademark2_information");
        next_fs = $("#trademark3_information");
      }

      next_fs.show();
      current_fs.hide();
    }
  });

  $("#previous").click(function () {
    if ($("#trademark2_information").is(":visible")) {
      current_fs = $("#trademark2_information");
      next_fs = $("#trademark1_information");
    } else if ($("#trademark3_information").is(":visible")) {
      current_fs = $("#trademark3_information");
      next_fs = $("#trademark2_information");
    }
    next_fs.show();
    current_fs.hide();
  });
});
