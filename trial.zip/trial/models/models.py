from odoo import fields, models, api, _


class TrialApplication(models.Model):
    _name = "trial.application"
    _rec_name = "registrationPart"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    id(_name)

    def get_document_count(self):
        count = self.env['trial.application'].search_count([('telephone', '=', 'self.id')])
        self.document_count = count

        # for the states
    def action_reviewer(self):
        for rec in self:
            rec.state = 'reviewer'

    def action_approver(self):
        for rec in self:
            rec.state = 'approver'

    def action_confirm(self):
        for rec in self:
            rec.state = 'confirm'

    registrationPart = fields.Char("Registration Part Of")
    registrationServicesClass = fields.Char("Registration Services Class")
    agencyType = fields.Char("Agency Type")
    companyName = fields.Char("Company Name")
    trademarkStatus = fields.Char("Trademark Status")
    uploadFile = fields.Binary("File Uploaded")
    additionalInfo = fields.Char("Additional Information")
    address = fields.Char("Address")
    email = fields.Char("Email")
    telephone = fields.Char("Telephone")
    document_count = fields.Integer(string='Documents', compute='get_document_count')

    # for the action button
    @api.multi
    def applicant_documents(self):
        return {
            'name': _('Documents'),
            'domain': [('telephone', '=', 'self.id')],
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'trial.application',
            # 'res_id': session_id,
            'view_id': False,
            'type': 'ir.actions.act_window',
        }

    state = fields.Selection([
        ('draft', 'Draft'),
        ('reviewer', 'Reviewer'),
        ('approver', 'Approver'),
        ('confirm', 'Confirm'),
    ], string='Status', readonly=True, default='draft')