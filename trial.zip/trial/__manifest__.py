{
    'name': 'trial',
    'version': '12.0.1.0',
    'author': 'Ndagire Jesca',
    'summary': 'URSB Trademark Application System',
    'sequence': '1',
    'description': 'This is an online trademark  application system that is supported in Odoo v12',
    'category': 'Extra Tools',
    'website': 'https://freeweblearns.blogspot.com',
    'depends': ["base", "website", "website_sale"],
    'data': [
        'security/ir.model.access.csv',
        'views/appAdmin.xml',
        'views/trademark.xml',



    ],
    'application': True,
    'installable': True,
}
